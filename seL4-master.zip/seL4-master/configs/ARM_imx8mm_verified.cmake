#!/usr/bin/env -S cmake -P
#
# Copyright 2024, Proofcraft Pty Ltd
#
# SPDX-License-Identifier: GPL-2.0-only
#

include(${CMAKE_CURRENT_LIST_DIR}/include/ARM_verified_include.cmake)

set(KernelPlatform "imx8mm-evk" CACHE STRING "")
set(KernelAArch32FPUEnableContextSwitch ON CACHE BOOL "" FORCE)
